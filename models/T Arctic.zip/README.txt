materials/models/player/custom_player/eminem/css/t_arctic/t_arctic.vmt
materials/models/player/custom_player/eminem/css/t_arctic/t_arctic.vtf
materials/models/player/custom_player/eminem/css/t_arctic/t_arctic_normal.vtf

models/player/custom_player/eminem/css/t_arctic.dx90.vtx
models/player/custom_player/eminem/css/t_arctic.vvd
models/player/custom_player/eminem/css/t_arctic.mdl
models/player/custom_player/eminem/css/t_arctic.phy